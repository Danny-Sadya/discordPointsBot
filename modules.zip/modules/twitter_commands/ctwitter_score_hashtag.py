import config
from modules.general_commands import gen_abort_command


def check(m):
    return config.ADMIN_ID == m.author.id


async def score_twitter_hashtag(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        old_score = db_executor.get_twitter_hashtag_score()
        if old_score == 0:
            await ctx.author.send('What is the value of the chosen hashtag(s) on Twitter?')
        else:
            await ctx.author.send('What is the new value of the chosen hashtag(s) on Twitter?')

        msg = await bot.wait_for('message', check=check)

        if msg.content != 'abort_command':
            try:
                score = float(msg.content)
                db_executor.set_twitter_hashtag_score(score)
                await ctx.author.send(f'Thank you! The value of the chosen hashtag(s) is set to {score}')
            except:
                await ctx.author.send(f'{msg.content} is not a digit...')
                await score_twitter_hashtag(ctx, bot, db_executor)
        else:
            aborted = await gen_abort_command.abort_command(ctx, bot)

            if not aborted:
                await score_twitter_hashtag(ctx, bot, db_executor)
