import time


async def on_voice_state_update(member, before, after, tdict, db_executor):
    author = member.id
    contest = db_executor.is_contest_active()
    registration = db_executor.get_registration_status()

    is_user_registered = db_executor.is_user_registered(user_id=author)
    if registration and not is_user_registered:
        is_user_registered = True
        db_executor.set_user_registration_status(user_id=author)
        print('New user is registered to contest')

    if contest and is_user_registered:
        if before.channel is None and after.channel is not None:
            print('Connection to voice chat inited', member, member.id)
            t1 = time.time()
            tdict[author] = t1
        elif before.channel is not None and after.channel is None and author in tdict:
            t2 = time.time()
            print('Connection to voice chat closed', member, member.id)
            print(t2 - tdict[author])
            # TODO ADDING POINTS PER MINUTE
            del tdict[author]


#
# async def on_voice_state_update(self, member, before, after):
#     author = member.id
#     if before.channel is None and after.channel is not None:
#         print('Connection to voice chat inited', member, member.id)
#         t1 = time.time()
#         self.tdict[author] = t1
#     elif before.channel is not None and after.channel is None and author in self.tdict:
#         t2 = time.time()
#         print('Connection to voice chat closed', member, member.id)
#         print(t2 - self.tdict[author])
#         del self.tdict[author]
#         print('Need to update user points')
