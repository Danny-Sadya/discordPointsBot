async def on_member_join(member, db_executor):
    print(f'{member.name} has join the channel')
    db_executor.add_id(int(member.id))
    if not db_executor.is_user_already_invited(int(member.id)):
        gld = member.guild
        invite_codes = await gld.invites()
        for invite_code in invite_codes:
            db_executor.set_user_invite_code(int(invite_code.inviter.id), str(invite_code.code))
            for inviter_data in db_executor.get_invites_data():
                print(inviter_data)
                if not db_executor.is_user_already_invited(int(member.id)):
                    if inviter_data[0] == invite_code.code:
                        if int(invite_code.uses) > inviter_data[1]:
                            print(f'{member.name} joined by {invite_code.inviter.name} refferal link')
                            db_executor.set_user_invite_code_uses(int(invite_code.inviter.id), int(invite_code.uses))
                            db_executor.set_user_status_to_invited(int(member.id))
                            contest = db_executor.is_contest_active()
                            registration = db_executor.get_registration_status()
                            is_user_registered = db_executor.is_user_registered(invite_code.inviter.id)
                            if registration and not is_user_registered:
                                is_user_registered = True
                                db_executor.set_user_registration_status(user_id=invite_code.inviter.id)
                            if contest and is_user_registered:
                                points = db_executor.get_discord_invite_score()
                                db_executor.update_points(int(invite_code.inviter.id), points)
                else:
                    break


    # async def on_member_join(self, member):
    #     print(f'{member.name} has join the channel')
    #     self.db_executor.add_id(int(member.id))
    #     if not self.db_executor.is_user_already_invited(int(member.id)):
    #         gld = self.guilds[0]
    #         invite_codes = await gld.invites()
    #         for invite_code in invite_codes:
    #             self.db_executor.set_user_invite_code(int(invite_code.inviter.id), str(invite_code.code))
    #             for inviter_data in self.db_executor.get_invites_data():
    #                 if not self.db_executor.is_user_already_invited(int(member.id)):
    #                     if inviter_data[0] == invite_code.code:
    #                         if int(invite_code.uses) > inviter_data[1]:
    #                             print(f'{member.name} joined by {invite_code.inviter.name} refferal link')
    #                             self.db_executor.set_user_invite_code_uses(int(invite_code.inviter.id), int(invite_code.uses))
    #                             self.db_executor.set_user_status_to_invited(int(member.id))
    #                             self.db_executor.update_points(int(invite_code.inviter.id), 1)
    #                 else:
    #                     break
    #     else:
    #         print(f'{member.name} had been earlier invited')