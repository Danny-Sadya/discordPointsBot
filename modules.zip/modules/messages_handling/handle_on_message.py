"""
If registration open and contest is started - register user and add points
If registration open and contest is not started - register user
If contest open and user is not registered - skip

"""


async def on_message(message, db_executor):
    contest = db_executor.is_contest_active()
    registration = db_executor.get_registration_status()
    author_id = message.author.id

    is_user_registered = db_executor.is_user_registered(user_id=author_id)
    if registration and not is_user_registered:
        is_user_registered = True
        db_executor.set_user_registration_status(user_id=author_id)
        print('New user is registered to contest')

    if contest and is_user_registered:
        if not message.content.split(' ')[0].startswith('!'):
            if message.type.name != "new_member":
                points = db_executor.get_discord_sent_message_score()
                db_executor.update_points(user_id=author_id, count=points)
                print(f'Message: {message.content}')
