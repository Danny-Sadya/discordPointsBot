async def on_raw_reaction_add(message, db_executor):
    contest = db_executor.is_contest_active()
    registration = db_executor.get_registration_status()
    author_id = message.user_id

    is_user_registered = db_executor.is_user_registered(user_id=author_id)
    if registration and not is_user_registered:
        is_user_registered = True
        db_executor.set_user_registration_status(user_id=author_id)
        print('New user is registered to contest')

    if contest and is_user_registered:
        points = db_executor.get_discord_react_score()
        db_executor.update_points(user_id=author_id, count=points)

