from random import randint
from modules.general_commands import gen_abort_command


async def select_winner(ctx, bot, db_executor):
    def check(m):
        return ctx.author.id== m.author.id

    await ctx.author.send('Initialization randomization protocol. Are you sure you want to roll the dice? (Y/N)')

    while True:
        msg = await bot.wait_for('message', check=check)
        if msg.content == "Y":
            data = db_executor.get_random_winner()
            random_number = randint(0, len(data) - 1)
            await ctx.author.send(f'Complete: The winner id is: {data[random_number][0]}! '
                                  f'Would you like to roll again? [Y/N]?')

        elif msg.content == "abort_command":
            aborted = await gen_abort_command.abort_command(ctx, bot)
            if not aborted:
                await select_winner(ctx, bot, db_executor)
            else:
                break
        else:
            await ctx.author.send('Command is closed')
            break
