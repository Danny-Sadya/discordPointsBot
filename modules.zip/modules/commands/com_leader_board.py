async def leader_board(ctx, db_executor):
    data = db_executor.get_top_hundred()
    stats = list(map(lambda x: f"id: {x[0]}, points: {x[1]}", data))
    data = ['Top 100 Leaderboard:\n']
    j = 0
    for i in stats:
        if len(data[j] + i + "\n") > 2000:
            data.append('')
            j += 1
        data[j] += i + "\n"

    for d in data:
        await ctx.author.send(d)
