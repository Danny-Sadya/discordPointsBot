comands = [
    '!help',
    '!servername',
    '!contestname',
    '!pointname',
    '!conteststartdate',
    '!contestenddate',
    '!startcontest',
    '!endcontest',
    '!pausecontest',
    '!registrationactive',
    '!registrationended',
    '!resetscores',
    '!checkscore',
    '!givepoints',  # Allows users to give points to another users
    '!transferpoints',
    '!allscores',
    '!leaderboard',
    '!topten',
    '!selectwinner'
]


async def help(ctx):
    await ctx.send(f'Admin commadns {comands}')