from modules.general_commands import gen_abort_command


async def all_scores(ctx, bot, db_executor):
    def check(m):
        return ctx.author.id== m.author.id

    await ctx.author.send('Initializing score card protocol.')
    data = db_executor.get_all_scores()
    await ctx.author.send('Protocol run complete - would you like to view? (Y/N)')
    msg = await  bot.wait_for('message', check=check)
    if msg.content == "Y":
        stats = list(map(lambda x: f"id: {x[0]}, points: {x[1]}", data))
        data = ["User's scores:\n"]
        j = 0
        for i in stats:
            if len(data[j] + i + "\n") > 2000:
                data.append('')
                j += 1
            data[j] += i + "\n"

        for d in data:
            await ctx.author.send(d)

    elif msg.content == "abort_command":
        aborted = await gen_abort_command.abort_command(ctx, bot)

        if not aborted:
            await all_scores(ctx, bot, db_executor)
    else:
        await ctx.author.send('Command is closed')