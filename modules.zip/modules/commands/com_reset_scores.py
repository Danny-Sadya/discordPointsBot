import config
from modules.general_commands import gen_abort_command


def check(m):
    return config.ADMIN_ID == m.author.id


async def reset_scores(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        await ctx.author.send('Score reset protocol has been initialized. All user scores will be reset to 0. '
                              'Are you sure you would like to proceed? (Y/N)')

        msg = await bot.wait_for('message', check=check)
        if msg.content == "Y":
            db_executor.reset_scores()
            await ctx.author.send('Scores have been zeroed!')
        elif msg.content == 'abort_command':
            aborted = await gen_abort_command.abort_command(ctx, bot)
            if not aborted:
                await reset_scores(ctx, bot, db_executor)
        else:
            await ctx.author.send('Command stopped')
