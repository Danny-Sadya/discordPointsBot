from modules.general_commands import gen_abort_command
import config


async def transfer_points(ctx, bot, db_executor):
    def check(m):
        return ctx.author.id == m.author.id

    await ctx.author.send('Transfer protocol initialized, please input the name of the user you would '
                    'like to receive the transfer')

    msg = await bot.wait_for('message', check=check)
    if msg.content != 'abort_command':
        users = bot.get_all_members()
        is_user_found = False
        for x in users:
            if x.name == msg.content:
                is_user_found = True
                await ctx.author.send('Perfect! Please input the amount of points '
                                      f'that you would like to transfer to {x.name}')

                msg2 = await bot.wait_for('message', check=check)
                if msg2.content != "abort_command":
                    try:
                        count = int(msg2.content)
                        author_points = db_executor.get_user_points(ctx.author.id)
                        if float(author_points) >= count:
                            db_executor.update_points(x.id, count)
                            db_executor.update_points(ctx.author.id, -count)
                            await ctx.author.send(f'You have transferred {count} point(s) to {x.name}')
                        else:
                            await ctx.author.send("You don't have enought points")
                    except:
                        await ctx.author.send(f'{msg2.content} is not a number')
                else:
                    aborted = await gen_abort_command.abort_command(ctx, bot)

                    if not aborted:
                        await transfer_points(ctx, bot, db_executor)
                break
        if not is_user_found:
            await ctx.author.send('User was not found')


    else:
        aborted = await gen_abort_command.abort_command(ctx, bot)

        if not aborted:
            await transfer_points(ctx, bot, db_executor)

