async def resetstatistics(ctx, db_executor):
    db_executor.reset_statistics()
    await ctx.send("User's points and registration status is reseted")
