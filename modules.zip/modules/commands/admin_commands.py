commands = [
    '!admin_help',
    '!servername',
    '!contestname',
    '!pointname',
    '!conteststartdate',
    '!contestenddate',
    '!startcontest',
    '!endcontest',
    '!pausecontest',
    '!registrationactive',
    '!registrationended',
    '!resetscores',
    '!checkscore',
    '!givepoints',  # Allows users to give points to another users
    '!transferpoints',
    '!allscores',
    '!leaderboard',
    '!topten',
    '!selectwinner'
]