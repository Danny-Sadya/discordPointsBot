async def check_score(ctx, bot, db_executor):
    points = db_executor.get_user_points(ctx.author.id)

    await ctx.author.send(f'Your current score is: {round(points, 2)}')