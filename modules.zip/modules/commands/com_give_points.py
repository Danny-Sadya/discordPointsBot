import config
from modules.general_commands import gen_abort_command



async def give_points(ctx, bot, db_executor):
    def check(m):
        return ctx.author.id== m.author.id

    can_user_give_points = True
    if can_user_give_points:
        point_name = db_executor.get_point_name()
        await ctx.author.send(f'Tip protocol initialized. Who would you like to tip with {point_name}? Input username')

        msg = await bot.wait_for('message', check=check)
        if msg.content != "abort_command":
            users = bot.get_all_members()
            is_user_found = False
            for x in users:
                if x.name == msg.content:
                    is_user_found = True
                    await ctx.author.send(f'Okay how many points would you like to tip {x.name}')

                    msg2 = await bot.wait_for('message', check=check)
                    if msg2.content != "abort_command":
                        try:
                            count = int(msg2.content)
                            db_executor.update_points(x.id, count)
                            await ctx.author.send(f'{x.name} has been issued {msg2.content} points')
                        except:
                            await ctx.author.send(f'{msg2.content} is not a number')
                    else:
                        aborted = await gen_abort_command.abort_command(ctx, bot)

                        if not aborted:
                            await give_points(ctx, bot, db_executor)
                    break
            if not is_user_found:
                await ctx.author.send('User was not found')

        else:
            aborted = await gen_abort_command.abort_command(ctx, bot)

            if not aborted:
                await give_points(ctx, bot, db_executor)

