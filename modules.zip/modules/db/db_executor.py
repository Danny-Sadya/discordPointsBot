import os
import sqlite3
from pathlib import Path
from db.contest_commands import *
from db.user_commands import *
from db.scores import *


class DbExecutor:
    def __init__(self, database_name='identifier.sqlite'):
        self.database_name = database_name
        try:
            self.conn = sqlite3.connect(os.path.join(Path(__file__).parent.parent.parent, self.database_name))
        except Exception as ex:
            print(f'Connection to database error: {ex}')

    def add_id(self, user_id):
        add_id(self.conn, user_id)

    def update_points(self, user_id, count):
        update_points(self.conn, user_id, count)

    def get_user_points(self, user_id):
        return get_user_points(self.conn, user_id)

    def get_user_invite_data(self, user_id):
        return get_user_invite_data(self.conn, user_id)

    def set_user_invite_code(self, user_id, invite_code):
        set_user_invite_code(self.conn, user_id, invite_code)

    def set_user_invite_code_uses(self, user_id, invite_code_uses):
        set_user_invite_code_uses(self.conn, user_id, invite_code_uses)

    def get_invites_data(self):
        return get_invites_data(self.conn)

    def is_user_already_invited(self, user_id):
        return is_user_already_invited(self.conn, user_id)

    def set_user_status_to_invited(self, user_id):
        set_user_status_to_invited(self.conn, user_id)

    def get_server_name(self):
        return get_server_name(self.conn)

    def set_server_name(self, server_name):
        set_server_name(self.conn, server_name)

    def get_contest_name(self):
        return get_contest_name(self.conn)

    def set_contest_name(self, contest_name):
        set_contest_name(self.conn, contest_name)

    def get_point_name(self):
        return get_point_name(self.conn)

    def set_point_name(self, point_name):
        set_point_name(self.conn, point_name)

    def get_manual_control_status(self):
        return get_manual_control_status(self.conn)

    def set_manual_control_status(self, status):
        set_manual_control_status(self.conn, status)

    def get_registration_status(self):
        return get_registration_status(self.conn)

    def set_registration_status(self, status):
        set_registration_status(self.conn, status)

    def get_check_score_status(self):
        return get_check_score_status(self.conn)

    def set_check_score_status(self, status):
        set_check_score_status(self.conn, status)

    def get_give_points_status(self):
        return get_give_points_status(self.conn)

    def set_give_points_status(self, status):
        set_give_points_status(self.conn, status)

    def get_transfer_points_status(self):
        return get_transfer_points_status(self.conn)

    def set_transfer_points_status(self, status):
        set_transfer_points_status(self.conn, status)

    def get_contest_start_date(self):
        return get_contest_start_date(self.conn)

    def set_contest_start_date(self, date):
        set_contest_start_date(self.conn, date)

    def get_contest_end_date(self):
        return get_contest_end_date(self.conn)

    def set_contest_end_date(self, date):
        set_contest_end_date(self.conn, date)

    def get_all_scores(self):
        return get_all_scores(self.conn)

    def reset_scores(self):
        reset_scores(self.conn)

    def get_top_ten(self):
        return get_top_ten(self.conn)

    def get_top_hundred(self):
        return get_top_hundred(self.conn)

    def get_random_winner(self):
        return get_random_winner(self.conn)

    def reset_statistics(self):
        reset_statistics(self.conn)

    def is_user_registered(self, user_id):
        return is_user_registered(self.conn, user_id)

    def set_user_registration_status(self, user_id):
        set_user_registration_status(self.conn, user_id)

    def is_contest_active(self):
        return is_contest_active(self.conn)

    def get_twitter_hashtags(self):
        return get_twitter_hashtags(self.conn)

    def set_twitter_hashtags(self, hashtags):
        set_twitter_hashtags(self.conn, hashtags)

    def get_instagram_hashtags(self):
        return get_instagram_hashtags(self.conn)

    def set_instagram_hashtags(self, hashtags):
        set_instagram_hashtags(self.conn, hashtags)

    def get_twitter_api_key(self):
        return get_twitter_api_key(self.conn)

    def get_instagram_api_key(self):
        return get_instagram_api_key(self.conn)

    def set_twitter_api_key(self, api_key):
        set_twitter_api_key(self.conn, api_key)

    def set_instagram_api_key(self, api_key):
        set_instagram_api_key(self.conn, api_key)

    def set_discord_sent_message_score(self, score):
        set_discord_sent_message_score(self.conn, score)

    def get_discord_sent_message_score(self):
        return get_discord_sent_message_score(self.conn)

    def set_discord_react_score(self, score):
        set_discord_react_score(self.conn, score)

    def get_discord_react_score(self):
        return get_discord_react_score(self.conn)

    def set_discord_time_score(self, score):
        set_discord_time_score(self.conn, score)

    def get_discord_time_score(self):
        return get_discord_time_score(self.conn)

    def set_discord_invite_score(self, score):
        set_discord_invite_score(self.conn, score)

    def get_discord_invite_score(self):
        return get_discord_invite_score(self.conn)

    def set_instagram_like_score(self, score):
        set_instagram_like_score(self.conn, score)

    def get_instagram_like_score(self):
        return get_instagram_like_score(self.conn)

    def set_instagram_comment_score(self, score):
        set_instagram_comment_score(self.conn, score)

    def get_instagram_comment_score(self):
        return get_instagram_comment_score(self.conn)

    def set_instagram_follow_score(self, score):
        set_instagram_follow_score(self.conn, score)

    def get_instagram_follow_score(self):
        return get_instagram_follow_score(self.conn)

    def set_instagram_hashtag_score(self, score):
        set_instagram_hashtag_score(self.conn, score)

    def get_instagram_hashtag_score(self):
        return get_instagram_hashtag_score(self.conn)

    def set_twitter_retweet_score(self, score):
        set_twitter_retweet_score(self.conn, score)

    def get_twitter_retweet_score(self):
        return get_twitter_retweet_score(self.conn)

    def set_twitter_quote_tweet_score(self, score):
        set_twitter_quote_tweet_score(self.conn, score)

    def get_twitter_quote_tweet_score(self):
        return get_twitter_quote_tweet_score(self.conn)

    def set_twitter_tweet_like_score(self, score):
        set_twitter_tweet_like_score(self.conn, score)

    def get_twitter_tweet_like_score(self):
        return get_twitter_tweet_like_score(self.conn)

    def set_twitter_twit_tagged_score(self, score):
        set_twitter_twit_tagged_score(self.conn, score)

    def get_twitter_twit_tagged_score(self):
        return get_twitter_twit_tagged_score(self.conn)

    def set_twitter_hashtag_score(self, score):
        set_twitter_hashtag_score(self.conn, score)

    def get_twitter_hashtag_score(self):
        return get_twitter_hashtag_score(self.conn)

    def set_twitter_follow_score(self, score):
        set_twitter_follow_score(self.conn, score)

    def get_twitter_follow_score(self):
        return get_twitter_follow_score(self.conn)






if __name__ == "__main__":
    db_executor = DbExecutor()
    print(db_executor.get_all_scores())
