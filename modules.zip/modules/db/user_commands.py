def add_id(conn, user_id):
    try:
        cursor = conn.cursor()
        script = """INSERT OR IGNORE INTO stats(id) VALUES (?)"""
        cursor.execute(script, (user_id,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while adding new user in database: {ex}')


def update_points(conn, user_id, count):
    try:
        cursor = conn.cursor()
        try:
            script = """INSERT INTO stats (id, points) VALUES (?, ?);"""
            cursor.execute(script, (user_id, count))
        except Exception:
            script = """UPDATE stats SET points = points + (?) WHERE id = (?)"""
            cursor.execute(script, (count, user_id))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while updating points count: {ex}')


def get_user_points(conn, user_id):
    try:
        script = """SELECT points FROM stats WHERE id = (?)"""
        cursor = conn.cursor()
        cursor.execute(script, (user_id,))
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting points: {ex}')


def get_user_invite_data(conn, user_id):
    try:
        cursor = conn.cursor()
        script = """INSERT OR IGNORE INTO stats (id) VALUES (?);"""
        cursor.execute(script, (user_id,))
        script = """SELECT invite_code, invite_code_uses FROM stats where id = (?)"""
        cursor.execute(script, (user_id,))
        data = cursor.fetchone()
        cursor.close()
        conn.commit()
        return data
    except Exception as ex:
        print(f'Error while getting user invites data: {ex}')


def set_user_invite_code(conn, user_id, invite_code):
    try:
        cursor = conn.cursor()
        script = """INSERT OR IGNORE INTO stats (id, invite_code) VALUES (?, ?);"""
        cursor.execute(script, (user_id, invite_code))
        script = """SELECT invite_code FROM stats WHERE id = (?)"""
        cursor.execute(script, (user_id,))
        if cursor.fetchone()[0] != invite_code:
            script = """UPDATE stats SET invite_code_uses = 0 WHERE id = (?)"""
            cursor.execute(script, (user_id,))
        script = """UPDATE stats SET invite_code = (?) WHERE id = (?)"""
        cursor.execute(script, (invite_code, user_id))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting user invite code: {ex}')


def set_user_invite_code_uses(conn, user_id, invite_code_uses):
    try:
        cursor = conn.cursor()
        script = """UPDATE stats SET invite_code_uses = (?) WHERE id = (?)"""
        cursor.execute(script, (invite_code_uses, user_id))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting user invite code uses: {ex}')


def get_invites_data(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT invite_code, invite_code_uses FROM stats"""
        cursor.execute(script)
        data = cursor.fetchall()
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting invites data: {ex}')


def is_user_already_invited(conn, user_id):
    try:
        cursor = conn.cursor()
        script = """SELECT is_invited FROM stats WHERE id = (?)"""
        cursor.execute(script, (user_id,))
        data = cursor.fetchone()[0]
        cursor.close()
        return True if data == 1 else False
    except Exception as ex:
        print(f'Error while getting user invited status: {ex}')


def set_user_status_to_invited(conn, user_id):
    try:
        cursor = conn.cursor()
        script = """UPDATE stats SET is_invited = TRUE where id = (?)"""
        cursor.execute(script, (user_id,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting user status to invited: {ex}')


def get_all_scores(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT id, points FROM stats"""
        cursor.execute(script)
        data = cursor.fetchall()
        cursor.close()
        d = []
        for i in range(0, len(data)):
            d.append((data[i][0], round(data[i][1], 2)))
        return d
    except Exception as ex:
        print(f"Error while getting all user's scores: {ex}")


def reset_scores(conn):
    try:
        cursor = conn.cursor()
        script = """UPDATE stats SET points = 0"""
        cursor.execute(script)
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f"Error while reseting user's scores: {ex}")


def get_top_ten(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT id, points FROM stats ORDER BY points DESC LIMIT 10"""
        cursor.execute(script)
        data = cursor.fetchall()
        cursor.close()
        d = []
        for i in range(0, len(data)):
            d.append((data[i][0], round(data[i][1], 2)))
        return d
    except Exception as ex:
        print(f'Error while getting top 10 leaderboard: {ex}')
        

def get_top_hundred(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT id, points FROM stats ORDER BY points DESC LIMIT 100"""
        cursor.execute(script)
        data = cursor.fetchall()
        cursor.close()
        d = []
        for i in range(0, len(data)):
            d.append((data[i][0], round(data[i][1], 2)))
        return d
    except Exception as ex:
        print(f'Error while getting top 100 leaderboard: {ex}')


def get_random_winner(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT id FROM stats"""
        cursor.execute(script)
        data = cursor.fetchall()
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting random winner: {ex}')


def reset_statistics(conn):
    try:
        cursor = conn.cursor()
        script = """UPDATE stats SET (is_registered, points) = (FALSE, 0)"""
        cursor.execute(script)
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f"Error while reseting user's statiscics: {ex}")


def is_user_registered(conn, user_id):
    try:
        cursor = conn.cursor()
        script = """INSERT OR IGNORE INTO stats(id) VALUES (?)"""
        cursor.execute(script, (user_id,))
        script = """SELECT is_registered FROM stats WHERE id = (?)"""
        cursor.execute(script, (user_id,))
        data = cursor.fetchone()[0]
        cursor.close()
        return True if data == 1 else False
    except Exception as ex:
        print(f'Error while getting user registration status: {ex}')


def set_user_registration_status(conn, user_id):
    try:
        cursor = conn.cursor()
        script = """INSERT OR IGNORE INTO stats (id) VALUES (?);"""
        cursor.execute(script, (user_id,))
        script = """UPDATE stats SET is_registered = TRUE WHERE id = (?)"""
        cursor.execute(script, (user_id,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting user registration status: {ex}')
