def set_discord_sent_message_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET sent_message=(?) WHERE id=(0)"""
        cursor.execute(script, (value, ))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting discord sent message score: {ex}')


def get_discord_sent_message_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT sent_message FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting discord send message score: {ex}')


def set_discord_react_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET react=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting discord react score: {ex}')


def get_discord_react_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT react FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting discord react score: {ex}')


def set_discord_time_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET vc_time=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting discord voice time score: {ex}')


def get_discord_time_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT vc_time FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting discord time score: {ex}')


def set_discord_invite_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET invite=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting discord invite score: {ex}')


def get_discord_invite_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT invite FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting discord invite score: {ex}')


def set_instagram_like_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET ig_like=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting instagram like score: {ex}')


def get_instagram_like_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT ig_like FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting instagram like score: {ex}')


def set_instagram_comment_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET ig_comment=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting instagram comment score: {ex}')


def get_instagram_comment_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT ig_comment FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting instagram comment score: {ex}')


def set_instagram_follow_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET ig_follow=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting instagram follow score: {ex}')


def get_instagram_follow_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT ig_follow FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting instagram follow score: {ex}')


def set_instagram_hashtag_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET hashtag=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting instagram hashtag score: {ex}')


def get_instagram_hashtag_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT hashtag FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting instagram hashtag score: {ex}')


def set_twitter_retweet_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET retweet=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting twitter retweet score: {ex}')


def get_twitter_retweet_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT retweet FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting twitter retweet score: {ex}')


def set_twitter_quote_tweet_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET quote_tweet=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting twitter quote tweet score: {ex}')


def get_twitter_quote_tweet_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT quote_tweet FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting twitter quote tweet score: {ex}')


def set_twitter_tweet_like_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET tweet_like=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting twitter tweet like score: {ex}')


def get_twitter_tweet_like_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT tweet_like FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting twitter tweet like score: {ex}')


def set_twitter_twit_tagged_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET twit_tagged=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting twitter twit tagged score: {ex}')


def get_twitter_twit_tagged_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT twit_tagged FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting twitter twit tagged score: {ex}')


def set_twitter_hashtag_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET hashtag_t=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting twitter hashtag score: {ex}')


def get_twitter_hashtag_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT hashtag_t FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while gettign twitter hashtag score: {ex}')


def set_twitter_follow_score(conn, value):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET twit_follow=(?) WHERE id=(0)"""
        cursor.execute(script, (value,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting twitter follow score: {ex}')


def get_twitter_follow_score(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT twit_follow FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting twitter follow score: {ex}')
