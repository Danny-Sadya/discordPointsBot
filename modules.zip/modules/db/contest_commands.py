from datetime import datetime


def get_server_name(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT server_name FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        return None
        print(f'Exception while getting server name {ex}')


def set_server_name(conn, server_name):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET server_name=(?) WHERE id=(0)"""
        cursor.execute(script, (server_name,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting server name {ex}')


def get_contest_name(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT contest_name FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        return None
        print(f'Exception while getting contest name {ex}')


def set_contest_name(conn, contest_name):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET contest_name=(?) WHERE id=(0)"""
        cursor.execute(script, (contest_name,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting contest name {ex}')


def get_point_name(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT point_name FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:

        print(f'Exception while getting point name {ex}')


def set_point_name(conn, point_name):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET point_name=(?) WHERE id=(0)"""
        cursor.execute(script, (point_name,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting point name {ex}')


def get_manual_control_status(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT manual_control_status FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        return None
        print(f'Exception while getting manual control status {ex}')


def set_manual_control_status(conn, status):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET manual_control_status=(?) WHERE id=(0)"""
        cursor.execute(script, (status,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting manual control status {ex}')


def get_registration_status(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT registration_status FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return True if data == 1 else False
    except Exception as ex:
        return None
        print(f'Exception while getting registration status {ex}')


def set_registration_status(conn, registration_status):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET registration_status=(?) WHERE id=(0)"""
        cursor.execute(script, (registration_status,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting registration status {ex}')


def get_check_score_status(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT check_score FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return True if data == 1 else False
    except Exception as ex:
        print(f'Exception while getting check score status {ex}')


def set_check_score_status(conn, status):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET check_score=(?) WHERE id=(0)"""
        cursor.execute(script, (status,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting check score status {ex}')


def get_give_points_status(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT give_points FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return True if data == 1 else False
    except Exception as ex:
        print(f'Exception while getting give points status {ex}')


def set_give_points_status(conn, status):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET give_points=(?) WHERE id=(0)"""
        cursor.execute(script, (status,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting give points status {ex}')


def get_transfer_points_status(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT transfer_points FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return True if data == 1 else False
    except Exception as ex:
        print(f'Exception while getting transfer points status {ex}')


def set_transfer_points_status(conn, status):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET transfer_points=(?) WHERE id=(0)"""
        cursor.execute(script, (status,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting transfer points status {ex}')


def get_contest_start_date(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT contest_start_date FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        return data
    except Exception as ex:
        return None
        print(f'Error while getting contest start date: {ex}')


def set_contest_start_date(conn, start_time):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET contest_start_date=(?) WHERE id=(0)"""
        cursor.execute(script, (start_time, ))
        cursor.close()
        conn.commit()
    except Exception as ex:
        return None
        print(f'Error while setting contest start date: {ex}')


def get_contest_end_date(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT contest_end_date FROM contest_config WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        return data
    except Exception as ex:
        print(f'Error while getting contest end date: {ex}')


def set_contest_end_date(conn, end_time):
    try:
        cursor = conn.cursor()
        script = """UPDATE contest_config SET contest_end_date=(?) WHERE id=(0)"""
        cursor.execute(script, (end_time,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting contest end date: {ex}')


def is_contest_active(conn):
        manual_control_status = get_manual_control_status(conn)
        try:
            start_date = datetime.strptime(get_contest_start_date(conn), '%m/%d/%Y')
            end_date = datetime.strptime(get_contest_end_date(conn), '%m/%d/Y')
        except:
            start_date = None
            end_date = None
        date_now = datetime.now()

        if manual_control_status == "ended" or manual_control_status == "paused":
            return False
        elif manual_control_status == 'started':
            return True
        elif start_date == None or end_date == None:
            return False
        elif start_date <= date_now <= end_date or manual_control_status == 'started':
            return True


def get_twitter_hashtags(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT twitter_hashtags FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Exception while getting twitter hashtags: {ex}')


def set_twitter_hashtags(conn, hashtags):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET twitter_hashtags=(?) WHERE id=(0)"""
        cursor.execute(script, (hashtags,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting twitter hashtags: {ex}')


def get_instagram_hashtags(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT instagram_hashtags FROM admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Exception while getting instagram hashtags: {ex}')


def set_instagram_hashtags(conn, hashtags):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET instagram_hashtags=(?) WHERE id=(0)"""
        cursor.execute(script, (hashtags,))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting instagram hashtags: {ex}')


def get_twitter_api_key(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT twitter_api_key from admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting twitter api key: {ex}')


def set_twitter_api_key(conn, api_key):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET twitter_api_key=(?) WHERE id=(0)"""
        cursor.execute(script, (api_key, ))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting twitter api key: {ex}')


def get_instagram_api_key(conn):
    try:
        cursor = conn.cursor()
        script = """SELECT instagram_api_key from admin_prefs WHERE id=(0)"""
        cursor.execute(script)
        data = cursor.fetchone()[0]
        cursor.close()
        return data
    except Exception as ex:
        print(f'Error while getting instagram api key: {ex}')


def set_instagram_api_key(conn, api_key):
    try:
        cursor = conn.cursor()
        script = """UPDATE admin_prefs SET instagram_api_key=(?) WHERE id=(0)"""
        cursor.execute(script, (api_key, ))
        cursor.close()
        conn.commit()
    except Exception as ex:
        print(f'Error while setting instagram api key: {ex}')
