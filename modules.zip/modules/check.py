from datetime import datetime
import time

t1 = datetime.now()
time.sleep(5)
t2 = datetime.now()
print((t2-t1).total_seconds())