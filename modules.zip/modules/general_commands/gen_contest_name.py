import json
from modules.general_commands import gen_abort_command, gen_point_name
import config


def check(m):
    return config.ADMIN_ID == m.author.id


async def contest_name(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        old_contest_name = db_executor.get_contest_name()

        if not old_contest_name:
            await ctx.author.send('What is the name of your upcoming contest?')
        else:
            await ctx.author.send('What is the new name of your upcoming contest?')

        msg = await bot.wait_for('message', check=check)

        if msg.content != "abort_command":
            db_executor.set_contest_name(msg.content)
            await ctx.author.send(f'Sounds great, your new contest is called {msg.content}')

            with open('states.json', 'r') as f:
                states = json.load(f)

            if states["start_setup"]:
                await gen_point_name.point_name(ctx, bot, db_executor)
                # await gen_setup_twitter.setup_twitter(ctx, bot, db_executor)


        elif msg.content == "abort_command":
            aborted = await gen_abort_command.abort_command(ctx, bot)

            if not aborted:
                await contest_name(ctx, bot, db_executor)