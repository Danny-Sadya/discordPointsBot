import json
from datetime import datetime
from modules.general_commands import gen_abort_command, gen_contest_end_date
import config


def check(m):
    return config.ADMIN_ID == m.author.id


async def contest_start_date(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        old_point_name = db_executor.get_contest_start_date()

        if not old_point_name:
            await ctx.author.send('What day would you like the contest to start? Please be sure to input the'
                                  'date in the following format: mm/dd/yyyy - '
                                  'If contest is to start manual simply input “none"')
        else:
            await ctx.author.send('What is the new contest start date?')

        msg = await bot.wait_for('message', check=check)

        if msg.content != "abort_command":
            try:
                datetime_object = datetime.strptime(msg.content, "%m/%d/%Y")
                db_executor.set_contest_start_date(msg.content)
                await ctx.author.send(f'Alright! We have set your contest start date for {msg.content}')
            except:
                if msg.content == 'none':
                    db_executor.set_contest_start_date(msg.content)
                    await ctx.author.send('Alright! You will control your contest manually')
                else:
                    db_executor.set_contest_start_date('none')
                    await ctx.author.send('Alright! You will control your contest manually')

            with open('states.json', 'r') as f:
                states = json.load(f)

            if states["start_setup"]:
                await gen_contest_end_date.contest_end_date(ctx, bot, db_executor)
        # await gen_setup_twitter.setup_twitter(ctx, bot, db_executor)

        elif msg.content == "abort_command":
            aborted = await gen_abort_command.abort_command(ctx, bot)

            if not aborted:
                await contest_start_date(ctx, bot, db_executor)