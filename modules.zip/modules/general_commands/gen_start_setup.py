import json
from modules.general_commands import gen_server_name, gen_abort_command
import config


def check(m):
    return config.ADMIN_ID == m.author.id


async def start_setup(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        await ctx.author.send(f'Welcome to {ctx.author.name} - In order to get started with all of the'
                              f' amazing features well need to run throught setup menu! '
                              f'Would you like to proceed (Y/N)?')

        msg = await bot.wait_for('message', check=check)

        if msg.content == 'Y':
            await ctx.author.send('Ok lets get started - well start with the server name '
                                  '(Advances to server name and activates auto advance)')

            with open('states.json', 'r') as f:
                states = json.load(f)
            states["start_setup"] = True
            states["server_name"] = True
            with open('states.json', 'w') as f:
                json.dump(states, f, indent=4)

            await gen_server_name.server_name(ctx, db_executor=db_executor, bot=bot)

        elif msg.content == 'N':
            await ctx.author.send('Configuration has been canceled!')

            with open('states.json', 'r') as f:
                states = json.load(f)

            for x in states.keys():
                states[x] = False
            with open('states.json', 'w') as f:
                json.dump(states, f, indent=4)

        elif msg.content == "abort_command":
            aborted = await gen_abort_command.abort_command(ctx, bot)
            if not aborted:
                await start_setup(ctx, bot, db_executor)

