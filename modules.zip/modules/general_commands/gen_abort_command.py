import json
import config


def check(m):
    return config.ADMIN_ID == m.author.id


async def abort_command(ctx, bot):
    if config.ADMIN_ID == ctx.author.id:
        await ctx.author.send('Abort command sequence initialized. Are you sure you would like to abort? [Y/N]')
        try:
            msg = await bot.wait_for('message', check=check)
            # TODO SET STATE TO WAIT FOR COMMAND
            if msg.content == "Y":
               with open('states.json', 'r') as f:
                states = json.load(f)

                for x in states.keys():
                    states[x] = False

                with open('states.json', 'w') as f:
                    json.dump(states, f)

                await ctx.author.send('Sequence has been successfully aborted.')
                return True
            if msg.content == "N":
                await ctx.author.send('Sequence aborting has been canceled. Continuing')
                return False

        except Exception as ex:
            print(ex)
            await ctx.author.send('Error - sequence cannot be aborted. Please try again. If that does not '
                            'finish the current command and re-run the abort command')