import json
from modules.general_commands import gen_abort_command, gen_setup_instagram_hashtag
import config


def check(m):
    return config.ADMIN_ID == m.author.id


async def setup_instagram(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        await ctx.author.send('Instagram setup protocol initialized: In order to connect to your Instagram account '
                        'well need the API Key. Please input your Instagram API Key for now')

        msg = await bot.wait_for('message', check=check)

    #     TODO TWITTER API KEY CHECKING
        api_key = msg.content
        while True:
            if api_key != "abort_command":
                check_api_key = True
                if check_api_key:
                    await ctx.author.send('Thanks! We have successfully connected to Instagram account Account Name')
                    # TODO ADD API KEY TO DB
                    db_executor.set_instagram_api_key(api_key)
                    with open('states.json', 'r') as f:
                        states = json.load(f)
                    states["setup_instagram_hashtag"] = True
                    with open('states.json', 'w') as f:
                        json.dump(states, f, indent=4)

                    if states["start_setup"]:
                        await gen_setup_instagram_hashtag.setup_instagram_hashtag(ctx, bot, db_executor)
                    break
                else:
                    await ctx.author.send("Hmm, that doesn't seem quite right. Lets try that one more time...")
                    msg = await bot.wait_for('message', check=check)
                    api_key = msg.content
            else:
                aborted = await gen_abort_command.abort_command(ctx, bot)
                if not aborted:
                    await setup_instagram(ctx, bot, db_executor)
                else:
                    break
