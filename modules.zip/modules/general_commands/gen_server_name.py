import json
from modules.general_commands import gen_setup_twitter, gen_abort_command
import config


def check(m):
    return config.ADMIN_ID == m.author.id


async def server_name(ctx, db_executor, bot):
    if config.ADMIN_ID == ctx.author.id:
        old_server_name = db_executor.get_server_name()

        if not old_server_name:
            await ctx.author.send('Server naming initialized. What is the name of your server?')
        else:
            await ctx.author.send('What is the new name of your server?')

        msg = await bot.wait_for('message', check=check)

        if msg.content != "abort_command":
            db_executor.set_server_name(msg.content)
            await ctx.author.send(f'Ok, from now your server will be called {msg.content}')

            with open('states.json', 'r') as f:
                states = json.load(f)
            states["setup_twitter"] = True
            with open('states.json', 'w') as f:
                json.dump(states, f, indent=4)

            if states["start_setup"]:
                await gen_setup_twitter.setup_twitter(ctx, bot, db_executor)


        elif msg.content == "abort_command":
            aborted = await gen_abort_command.abort_command(ctx, bot)

            if not aborted:
                await server_name(ctx, bot, db_executor)