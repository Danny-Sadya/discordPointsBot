import json
from modules.general_commands import gen_abort_command, gen_setup_instagram
import config


def check(m):
    return config.ADMIN_ID == m.author.id


async def setup_twitter_hashtag(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        await ctx.author.send("Hashtag protocol initialized. Please input the hashtag(s) "
                              "that you would like to monitor. If inputting multiple hashtags (up to 3) "
                              "please separate them by a ,")

        while True:
            msg = await bot.wait_for('message', check=check)
            if msg.content != 'abort_command':
                hashtags = msg.content.split(',')
                if len(hashtags) <= 3:
                    await ctx.author.send("Thanks! Hashtags have been successfully entered")
                    db_executor.set_twitter_hashtags(msg.content)
                    with open('states.json', 'r') as f:
                        states = json.load(f)
                    if states["start_setup"]:
                        await gen_setup_instagram.setup_instagram(ctx, bot, db_executor)
                    break
                else:
                    await ctx.author.send("Please re-enter the hashtag(s) that you would like to monitor. If inputting"
                                    "multiple hashtags (up to 3) please separate them by a ,")
            else:
                aborted = await gen_abort_command.abort_command(ctx, bot)
                if not aborted:
                    await setup_twitter_hashtag(ctx, bot, db_executor)
                else:
                    break
