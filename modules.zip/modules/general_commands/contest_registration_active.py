import json
import config
from modules.general_commands import gen_abort_command


def check(m):
    return config.ADMIN_ID == m.author.id


async def registration_active(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        await ctx.author.send('Are you sure you would like to open user registration? (Y/N)')

        msg = await bot.wait_for('message', check=check)

        if msg.content == 'Y':
            await ctx.author.send('User registration is now open')
            db_executor.set_registration_status(True)
        elif msg.content == "abort_command":
            aborted = await gen_abort_command.abort_command(ctx, bot)

            if not aborted:
                await registration_active(ctx, bot, db_executor)
        else:
            await ctx.author.send('Preparation stopped')
