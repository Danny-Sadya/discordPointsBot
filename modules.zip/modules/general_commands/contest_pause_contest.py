import json
import config
from modules.general_commands import gen_abort_command


def check(m):
    return config.ADMIN_ID == m.author.id


async def pause_contest(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        await ctx.author.send('Initializing pausing protocol. Are you sure you want to pause the contest? (Y/N)')

        msg = await bot.wait_for('message', check=check)
        if msg.content == 'Y':
            await ctx.author.send('Contest Paused!')
            db_executor.set_manual_control_status('paused')
        elif msg.content == "abort_command":
            aborted = await gen_abort_command.abort_command(ctx, bot)

            if not aborted:
                await pause_contest(ctx, bot, db_executor)
        else:
            await ctx.author.send('Preparation stopped')
