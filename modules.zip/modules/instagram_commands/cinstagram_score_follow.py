import config
from modules.general_commands import gen_abort_command


def check(m):
    return config.ADMIN_ID == m.author.id


async def score_instagram_follow(ctx, bot, db_executor):
    if config.ADMIN_ID == ctx.author.id:
        old_score = db_executor.get_instagram_follow_score()
        if old_score == 0:
            await ctx.author.send('What is the value of 1 follow on Instagram?')
        else:
            await ctx.author.send('What is the new value of 1 follow on Instagram?')

        msg = await bot.wait_for('message', check=check)

        if msg.content != 'abort_command':
            try:
                score = float(msg.content)
                db_executor.set_instagram_follow_score(score)
                await ctx.author.send(f'Thank you! The value of 1 follow is set to {score}')
            except:
                await ctx.author.send(f'{msg.content} is not a digit...')
                await score_instagram_follow(ctx, bot, db_executor)
        else:
            aborted = await gen_abort_command.abort_command(ctx, bot)

            if not aborted:
                await score_instagram_follow(ctx, bot, db_executor)
